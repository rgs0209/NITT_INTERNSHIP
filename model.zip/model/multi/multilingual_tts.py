from gtts import gTTS
print("Multilingual TTS Demo")
print("Examples of language codes: en (English), ta (Tamil), hi (Hindi), te (Telugu), ml (Malayalam)")
text = input("Enter text: ")
lang_code = input("Enter language code: ")
tts = gTTS(text=text, lang=lang_code)
file_name = f"speech_{lang_code}.mp3"
tts.save(file_name)
print(f"Audio saved as '{file_name}'")
print("You can now play it using your media player.")
try:
    import os
    os.system(f"start {file_name}")
except Exception as e:
    print("Could not auto-play audio:", e)
