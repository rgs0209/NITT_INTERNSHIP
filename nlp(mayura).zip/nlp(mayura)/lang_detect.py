import os
import requests
from dotenv import load_dotenv
from utils import get_headers
load_dotenv()
url = "https://api.sarvam.ai/text-lid"
sample_texts = [
    "வணக்கம், எப்படி இருக்கீங்க?",  
    "नमस्ते, कैसे हो?",             
    "Hello, how are you?",          
    "ഹലോ, സുഖമാണോ?"                
]
print("Language Detection Results:\n")
for text in sample_texts:
    payload = {"input": text}
    headers = get_headers()
    response = requests.post(url, json=payload, headers=headers)

    if response.status_code == 200:
        data = response.json()
        print(f" Text: {text}")
        print(f" Detected: {data.get('language_code')} (script: {data.get('script_code')})\n")
    else:
        print(" Error:", response.status_code, response.text)
