import os
from dotenv import load_dotenv
load_dotenv()

def get_headers(content_type="application/json"):
    """
    Returns the headers required for Sarvam API requests.
    """
    api_key = os.getenv("API_KEY")
    if not api_key:
        raise RuntimeError("Please set API_KEY in .env file")
    return {
        "api-subscription-key": api_key,
        "Content-Type": content_type
    }
