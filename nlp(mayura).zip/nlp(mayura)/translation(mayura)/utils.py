import os
from dotenv import load_doten
load_dotenv()
API_KEY = os.getenv("api_key")
if not api_key:
    raise RuntimeError(" set api_key in .env")
def get_headers(content_type="application/json"):
    headers = {"api-subscription-key": api_key}
    if content_type:
        headers["Content-Type"] = content_type
    return headers