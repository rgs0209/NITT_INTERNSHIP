import requests
import json
url = "https://api.sarvam.ai/text-analytics"

headers = {
    "Ocp-Apim-Subscription-Key":"sk_ksoi2eq0_HY58oMNQtAaKxqIXlnOhTC3G",
    "Accept": "application/json"
}
sample_text = "Sarvam AI is a multilingual NLP platform focused on Indian languages."
questions = [
    {"id":"q1","text":"Summarize the text", "type":"long answer"},
    {"id":"q2","text":"Return all Named Entities", "type":"long answer"},
    {"id":"q3","text":"Perform sentiment analysis", "type":"short answer"}
]
files = {
    "text": (None, sample_text),
    "questions": (None, json.dumps(questions)),
    "model": (None, "saaras:v1")
}
resp = requests.post(url, headers=headers, files=files)
print("Status code:", resp.status_code)
try:
    print(json.dumps(resp.json(), indent=2))
except:
    print(resp.text)
