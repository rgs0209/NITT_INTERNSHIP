import os
import requests
import json
from dotenv import load_dotenv
from utils import get_headers
load_dotenv()

def analyze_call(audio_file):
    url = "https://api.sarvam.ai/call-analytics"

    with open(audio_file, "rb") as f:
        files = {"file": ("sample_call.mp3", f, "audio/mpeg")}
        data = {
            "language_code": "en-IN",
            "questions": json.dumps([
                {"id": 1, "text": "Summarize this call", "type": "qa"},
                {"id": 2, "text": "What is the customer asking?", "type": "qa"},
                {"id": 3, "text": "What action should the agent take?", "type": "qa"}
            ])
        }
        headers = get_headers()
        headers.pop("Content-Type", None)  
        response = requests.post(url, headers=headers, files=files, data=data)
    if response.status_code == 200:
        result = response.json()
        print(" Call Analytics Result:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
    else:
        print(" Error:", response.status_code, response.text)
if __name__ == "__main__":
    audio_path = "sample_call.mp3"

    if os.path.exists(audio_path):
        analyze_call(audio_path)
    else:
        print(f"File {audio_path} not found. Please add an audio file.")
