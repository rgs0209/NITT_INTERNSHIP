import os
import requests
from dotenv import load_dotenv
load_dotenv()
api_key = os.getenv("api_key")
if not api_key:
    raise RuntimeError("set api_key in .env file")
url = "https://api.sarvam.ai/tts"
input_text = "Vanakkam! Idhu Bulbul Text to Speech api demo."
payload = {
    "inputs": [input_text]
    "target_language_code": "ta-IN",  
    "speaker": "neel",            
    "model": "bulbul:v1",
    "pitch": 0,
    "pace": 1.0,
    "loudness": 1.0,
    "enable_preprocessing": True
}
headers = {
    "api-subscription-key": api_key,
    "Content-Type": "application/json"
}
response = requests.post(url, json=payload, headers=headers)
if response.status_code == 200:
    with open("output.mp3", "wb") as f:
        f.write(response.content)
    print("Speech saved as output.mp3")
else:
    print("Error:" response.status_code, response.text)
