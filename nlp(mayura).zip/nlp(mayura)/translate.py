import requests
import json
from utils import get_headers
def translate_texts(input_texts):
    """
    Calls Sarvam Mayura translation endpoint for each target language.
    Uses the payload structure from your PDF.
    """
    url = "https://api.sarvam.ai/translate"
    headers = get_headers("application/json")
    langs = {
        "hi-IN":"Hindi","bn-IN":"Bengali","gu-IN":"Gujarati","kn-IN":"Kannada",
        "ml-IN":"Malayalam","mr-IN":"Marathi","od-IN":"Odia","pa-IN":"Punjabi",
        "ta-IN":"Tamil","te-IN":"Telugu"
    }
    all_results = {}
    for text in input_texts:
        all_results[text] = {}
        for code, lang_name in langs.items():
            payload = {
                "source_language_code": "en-IN",
                "target_language_code": code,
                "speaker_gender": "Male",
                "mode": "classic-colloquial",
                "model": "mayura:v1",
                "enable_preprocessing": False,
                "input": text
            }
            try:
                resp = requests.post(url, json=payload, headers=headers, timeout=15)
            except Exception as e:
                print(f"[{code}] Request failed: {e}")
                all_results[text][code] = {"error": str(e)}
                continue
            if not resp.ok:
                print(f"[{code}] ERROR {resp.status_code}: {resp.text}")
                all_results[text][code] = {"error": resp.text, "status_code": resp.status_code}
                continue
            try:
                data = resp.json()
            except ValueError:
                content = resp.content.decode('utf-8', errors='replace')
                print(f"[{code}] Non-JSON response: {content[:400]}")
                all_results[text][code] = {"raw": content}
                continue
            translated = data.get("translated_text")
            if translated is None:
                print(f"[{code}] response did not contain 'translated_text'full response saved for inspection.")
                all_results[text][code] = {"response": data}
            else:
                print(f"[{code} - {lang_name}] {translated}")
                all_results[text][code] = {"translated_text": translated}
    return all_results
if __name__ == "__main__":
    sample_inputs = [
        "Hello, good morning!",
    "I am learning NLP and AI.",
    "Please help me with my project."
    ]
    results = translate_texts(sample_inputs)
    with open("translations.json", "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print("\nAll translations saved to translations.json")
