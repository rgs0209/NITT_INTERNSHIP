import os
import requests
import subprocess
from dotenv import load_dotenv
load_dotenv()
API_KEY = os.getenv("API_KEY")
if not API_KEY:
    raise RuntimeError(" Please set API_KEY in .env file")
url = "https://api.sarvam.ai/text-to-speech"
input_text = "Vanakkam! Idhu Bulbul Text to Speech API demo."
payload = {
    "inputs": [input_text],
    "target_language_code": "ta-IN",  
    "speaker": "anushka",      
    "model": "bulbul:v2",    
    "pitch": 0.0,
    "pace": 1.0,
    "loudness": 1.0,
    "enable_preprocessing": True
}
headers = {
    "api-subscription-key": API_KEY,
    "Content-Type": "application/json"
}
response = requests.post(url, json=payload, headers=headers)
if response.status_code == 200:
    output_file = "output.mp3"
    with open(output_file, "wb") as f:
        f.write(response.content)
    print(f" Speech saved as {output_file}")
    subprocess.run(["start", output_file], shell=True)
else:
    print(" Error:", response.status_code, response.text)
