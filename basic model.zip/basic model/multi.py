from gtts import gTTS
from googletrans import Translator
translator = Translator()
print("English to Any Language - TTS Demo")
print("Examples of language codes: ta (Tamil), hi (Hindi), te (Telugu), ml (Malayalam)")
text_en = input("Enter text in English: ")
target_lang = input("Enter target language code: ")
translation = translator.translate(text_en, src='en', dest=target_lang)
print(f"Translated text ({target_lang}): {translation.text}")
tts = gTTS(text=translation.text, lang=target_lang)
file_name = f"speech_{target_lang}.mp3"
tts.save(file_name)
print(f"Audio saved as '{file_name}'")
print("Playing audio...")
import os
os.system(f"start {file_name}")