from gtts import gTTS
text = input("Enter text to speak: ")
tts = gTTS(text=text, lang='en')
tts.save("speech.mp3")
print(" saved as speech.mp3. play the audio")