import speech_recognition as sr
import pyttsx3
r = sr.Recognizer()
def record_text():
    while True:
        try:
            with sr.Microphone() as source2:
                print("listening")
                r.adjust_for_ambient_noise(source2, duration=0.2)
                audio2 = r.listen(source2)
                MyText = r.recognize_google(audio2, language="en-IN")
                print("recognized:", MyText)
                return MyText
        except sr.RequestError as e:
            print(" could not request results; {0}".format(e))
        except sr.UnknownValueError:
            print(" could not understand audio, please try again.")
def output_text(text):
    with open("output.txt", "a") as f:
        f.write(text + "\n")
    print(" wrote to output.txt")
while True:
    text = record_text()
    if text.lower() in ["stop", "exit"]:
        print("exiting program")
        break
    output_text(text)


